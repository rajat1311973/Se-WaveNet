We have created Jupyter notebooks to run different SE-wavnet models.
we have Integrated the SE-blocks at different CNN layers.
We trained all configurations of SE-wav2net models.
These are the following jupyter notebooks.
1. SE-Wavnet-at_layer_0.ipynb
2. SE-Wavnet-at_layer_1.ipynb
3. SE-Wavnet-at_layer_2.ipynb
4. SE-Wavnet-at_layer_3.ipynb
5. SE-Wavnet-at_layer_4.ipynb
6. SE-Wavnet-at_layer_5.ipynb
7. SE-Wavnet-at_layer_All.ipynb

data preprocessing and training of the model with results are given inside the jupyter notebooks.
We also performed MFCC distance analysis between pretrained wav2vec2.0 and finetuned wav2vec2.0 model.
then we also performed the same analysis with our proposed model SE-wavnet(finetuned on TIMIT dataset).
and we compared the results of the MFCC distances.

These are the following two notebooks for MFCC features distance analysis.
1. MFCC_Feature_Comparasion_of_finetune_and_pretrained_wav2vec2.ipynb
2. MFCC_Feature_Comparasion_with_SE-Wavnet-at-layer2.ipynb



